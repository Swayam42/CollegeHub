echo "Enter Ramesh's basic salary:"
read basic

da=$(echo "0.4 * $basic" | bc -l)
hra=$(echo "0.3 * $basic" | bc -l)
gross=$(echo "$basic + $da + $hra" | bc -l)

echo "Dearness Allowance: $da"
echo "House Rent Allowance: $hra"
echo "Gross Salary: $gross"
