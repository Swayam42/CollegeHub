echo "Enter a day:"
read day

case "$day" in
    Monday)    echo "DOS class: 10:00 AM - Room 101" ;;
    Tuesday)   echo "DOS class: 11:30 AM - Room 102" ;;
    Wednesday) echo "DOS class: 09:00 AM - Room 103" ;;
    Thursday)  echo "DOS class: 02:00 PM - Room 104" ;;
    Friday)    echo "DOS class: 03:30 PM - Room 105" ;;
    Saturday)  echo "No class on Saturday" ;;
    Sunday)    echo "Holiday" ;;
    *)         echo "Invalid day" ;;
esac
