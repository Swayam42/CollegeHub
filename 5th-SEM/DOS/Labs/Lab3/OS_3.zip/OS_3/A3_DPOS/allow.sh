echo "Enter internal mark:"
read mark
echo "Enter attendance percentage:"
read attend

if (( mark >= 20 )) && (( attend >= 75 )); then
    echo "Allowed for Semester"
else
    echo "Not allowed"
fi
