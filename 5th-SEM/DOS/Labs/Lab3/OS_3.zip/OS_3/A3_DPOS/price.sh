echo "Enter cost price:"
read cp
echo "Enter selling price:"
read sp

if (( $(echo "$sp > $cp" | bc -l) )); then
    profit=$(echo "$sp - $cp" | bc -l)
    echo "Profit: $profit"
elif (( $(echo "$sp < $cp" | bc -l) )); then
    loss=$(echo "$cp - $sp" | bc -l)
    echo "Loss: $loss"
else
    echo "No profit, no loss"
fi
