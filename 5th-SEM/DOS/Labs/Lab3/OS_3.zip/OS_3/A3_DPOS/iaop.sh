echo "Enter first num :"
read num1
echo "Enter sec num :"
read num2
sum=$((num1+num2))
echo "Sum of $num1 and $num2 is $sum"
