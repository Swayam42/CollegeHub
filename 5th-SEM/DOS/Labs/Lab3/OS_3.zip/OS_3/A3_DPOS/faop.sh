#!/bin/bash
echo "Enter first float num:"
read a
echo "Enter second float num:"
read b

sum=$(echo "$a + $b" | bc -l)
sub=$(echo "$a - $b" | bc -l)
mul=$(echo "$a * $b" | bc -l)

if (( $(echo "$b == 0" | bc -l) )); then
    div="Error: Division by zero"
else
    div=$(echo "scale=2; $a / $b" | bc -l)
fi

echo "Addition: $sum"
echo "Subtraction: $sub"
echo "Multiplication: $mul"
echo "Division: $div"
