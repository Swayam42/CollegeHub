even=0
odd=0

echo "Enter 10 numbers:"

for ((i=1; i<=10; i++))
do
    read num
    if (( num % 2 == 0 ))
    then
        ((even++))
    else
        ((odd++))
    fi
done

echo "Total even numbers: $even"
echo "Total odd numbers: $odd"
